class CustomException(Exception):
    pass