
API_KEY = 'your-api-key'
BASE_URL = 'https://api.example.com'